import logging

from django.contrib.auth.models import User
from django.db import transaction
from django.http import JsonResponse
from rest_framework import generics, permissions, viewsets
from rest_framework.decorators import action
from rest_framework.exceptions import AuthenticationFailed, PermissionDenied
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.views import TokenObtainPairView

from .models import Project, ProjectMembership, SecurityLog
from .permissions import IsProjectAdminOrReadOnly
from .repositories import TaskRepository
from .serializers import ProjectSerializer, TaskSerializer
from .serializers_auth import RegisterSerializer
from .services import MembershipService, TaskService
from .throttles import LoginRateThrottle

security_logger = logging.getLogger("security")


def health_check(request):
    return JsonResponse({"status": "ok", "service": "TaskFlow API"})


# ---------------------------------------------------------------------------
# Autenticación (Clase 6 + 7 + 8)
# ---------------------------------------------------------------------------
class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = RegisterSerializer
    permission_classes = [permissions.AllowAny]


class ThrottledTokenObtainPairView(TokenObtainPairView):
    """Clase 8: login con rate limiting + registro de intentos fallidos."""
    throttle_classes = [LoginRateThrottle]

    def post(self, request, *args, **kwargs):
        try:
            return super().post(request, *args, **kwargs)
        except AuthenticationFailed:
            ip = request.META.get("REMOTE_ADDR")
            username = request.data.get("username", "")
            SecurityLog.objects.create(
                action="login_failed",
                detail=f"usuario={username}",
                ip_address=ip,
            )
            security_logger.warning(
                f"Login fallido para usuario {username} desde {ip}"
            )
            raise


class SocialLoginJWTView(APIView):
    """
    Clase 7: después de loguearse con Google, allauth deja sesión de Django.
    Esta vista entrega un par de JWT propios.
    """
    def get(self, request):
        refresh = RefreshToken.for_user(request.user)
        return Response({
            "refresh": str(refresh),
            "access": str(refresh.access_token),
        })


# ---------------------------------------------------------------------------
# ViewSets (Clases 4-7)
# ---------------------------------------------------------------------------
class ProjectViewSet(viewsets.ModelViewSet):
    serializer_class = ProjectSerializer
    permission_classes = [permissions.IsAuthenticated, IsProjectAdminOrReadOnly]

    def get_queryset(self):
        return MembershipService.projects_for(self.request.user)

    def perform_create(self, serializer):
        # Quien crea el proyecto queda como su admin
        with transaction.atomic():
            project = serializer.save()
            ProjectMembership.objects.create(
                project=project,
                user=self.request.user,
                role="admin",
            )


class TaskViewSet(viewsets.ModelViewSet):
    serializer_class = TaskSerializer
    filterset_fields = ["status", "priority", "project"]
    ordering_fields = ["due_date", "created_at", "priority"]
    search_fields = ["title", "description"]
    permission_classes = [permissions.IsAuthenticated, IsProjectAdminOrReadOnly]

    def get_queryset(self):
        return (
            TaskRepository.get_queryset()
            .filter(project__memberships__user=self.request.user)
            .distinct()
        )

    def check_project_admin(self, project):
        if not MembershipService.is_admin(self.request.user, project):
            raise PermissionDenied(
                "Solo un admin del proyecto puede crear o mover tareas en él."
            )

    def perform_create(self, serializer):
        self.check_project_admin(serializer.validated_data["project"])
        serializer.save(owner=self.request.user)

    def perform_update(self, serializer):
        if "project" in serializer.validated_data:
            self.check_project_admin(serializer.validated_data["project"])
        serializer.save()

    @action(detail=True, methods=["post"])
    def complete(self, request, pk=None):
        task = self.get_object()
        TaskService.mark_completed(task)
        return Response(self.get_serializer(task).data)

    @action(detail=False, methods=["get"])
    def overdue(self, request):
        tasks = TaskService.tasks_overdue(self.get_queryset())
        page = self.paginate_queryset(tasks)
        if page is not None:
            return self.get_paginated_response(
                self.get_serializer(page, many=True).data
            )
        return Response(self.get_serializer(tasks, many=True).data)
